
import './App.css';
import SignUp from "./pages/SignUp";
import Login from "./pages/Login";
import Home from "./pages/home/Home";
import TopBar from "./components/topbar/TopBar";

function App() {
  return (
          <Home />


  );
}

export default App;
