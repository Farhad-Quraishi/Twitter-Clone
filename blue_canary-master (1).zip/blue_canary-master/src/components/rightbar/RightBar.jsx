import "./RightBar.css"
const RightBar = () => {
    return(
        <>
            <div className="rightBarContainer">
                <div className="friendsTitle">
                    <h1> Friends </h1>
                    <hr/>
                </div>
                <div className="friendsList">
                    <p> This is the area friends are shown.</p>

                </div>

            </div>
        </>
    );

}


export default RightBar;