import "./LeftBar.css"
const LeftBar = () => {
    return(
        <>
            <div className="midleftBarContainer">
                <div className="friendsTitle">
                    <h1> This is user's area </h1>
                </div>
                <div className="postArea">

                </div>


            </div>
        </>
    );
}


export default LeftBar;